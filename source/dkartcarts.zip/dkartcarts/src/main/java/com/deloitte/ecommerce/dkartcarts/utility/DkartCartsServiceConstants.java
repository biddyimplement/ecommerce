package com.deloitte.ecommerce.dkartcarts.utility;


public class DkartCartsServiceConstants  {
	
	public static String SUCCESS_MESSAGE_CART_DETAILS ="Item Added to your cart";
	public static final String KEY_SUCCESS= "Success";
    public static final String KEY_FAILURE= "Failure";
}
