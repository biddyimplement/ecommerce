package com.deloitte.ecommerce.dkartcarts.utility;

public class DkartCartsServiceQueries {

	public static final String deleteItemFromCart = "delete from cartdetails where cartdetailsid = :cartdetailsid";
}
